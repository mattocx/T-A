<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\CustomerPanelProvider::class,
    App\Providers\Filament\DashboardPanelProvider::class,
    App\Providers\Filament\SalesPanelProvider::class,
];
